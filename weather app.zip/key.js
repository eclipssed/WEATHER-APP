// asign the copied api key to a variable
// var key = "691e0b90dd58fa7b40d7658b3d124408";
key = '06582160730a7b97d403689a0febee5b'